/* Signal Room Editorial: evidence-led networking tutor with ink workspaces, cobalt signal paths, paper answer sheets, and asymmetric chapter navigation. */
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  ArrowDown,
  ArrowRight,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleAlert,
  Clipboard,
  Clock3,
  CloudUpload,
  Code2,
  Copy,
  FileArchive,
  FileCheck2,
  FileCode2,
  FileKey2,
  ShieldAlert,
  Gauge,
  HardDrive,
  KeyRound,
  Laptop,
  LockKeyhole,
  Menu,
  Moon,
  Network,
  Play,
  RotateCcw,
  Server,
  ShieldCheck,
  Sparkles,
  Sun,
  Terminal,
  TimerReset,
  Upload,
  Wifi,
  X,
  Zap,
} from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";

const sections = [
  { id: "home", label: "Overview", number: "00" },
  { id: "problem", label: "Problem", number: "01" },
  { id: "constraints", label: "Constraints", number: "02" },
  { id: "mode", label: "FTP mode", number: "03" },
  { id: "commands", label: "Commands", number: "04" },
  { id: "reliability", label: "Reliability", number: "05" },
  { id: "answer", label: "Exam answer", number: "06" },
];

const constraints = [
  {
    id: "firewall",
    icon: ShieldAlert,
    label: "Firewall",
    rule: "Outgoing connections only",
    impact: "Active FTP may fail because the server tries to open the data channel back to the client.",
    solution: "Choose Passive FTP so the client initiates both channels.",
    tone: "coral",
  },
  {
    id: "auth",
    icon: KeyRound,
    label: "Authentication",
    rule: "Username + password required",
    impact: "Anonymous access does not satisfy the access policy.",
    solution: "Authenticate with research_user and a password over the control connection.",
    tone: "blue",
  },
  {
    id: "payload",
    icon: FileArchive,
    label: "Payload",
    rule: "Large binary files up to 5 GB",
    impact: "Text transfer modes can corrupt archives and dataset bytes.",
    solution: "Use binary mode (TYPE I) and a resumable transfer strategy.",
    tone: "mint",
  },
  {
    id: "structure",
    icon: HardDrive,
    label: "File structure",
    rule: "Keep names + directories intact",
    impact: "A correct payload is not enough if it lands in the wrong location.",
    solution: "Navigate to /data/project and upload the original filename.",
    tone: "paper",
  },
];

const ftpSteps = [
  { label: "Connect", command: "ftp remote-server.example.com", response: "220 FTP Server Ready", detail: "Open the control connection to the remote FTP server." },
  { label: "Login", command: "USER research_user\nPASS ********", response: "230 Login successful", detail: "Authenticate with the required named account; anonymous login is not used." },
  { label: "Binary mode", command: "TYPE I", response: "200 Binary mode enabled", detail: "Send the ZIP file byte-for-byte without text conversion." },
  { label: "Passive mode", command: "EPSV", response: "229 Entering Extended Passive Mode", detail: "Ask the server for a passive data endpoint that the client can connect to." },
  { label: "Navigate", command: "CWD /data/project", response: "250 Directory changed successfully", detail: "Put the remote working directory in the same structure as the source." },
  { label: "Upload", command: "STOR dataset.zip", response: "150 Opening binary data connection", detail: "Stream the original archive name through the negotiated data channel." },
  { label: "Verify", command: "SIZE dataset.zip", response: "213 5368709120", detail: "Compare the remote byte count with the local file; use a checksum where supported." },
];

const answerText = `a) FTP Mode\n\nPassive FTP should be used. The client is behind a firewall that allows outgoing connections only and blocks incoming connections. In Active FTP, the server attempts to establish the data connection back to the client, so the firewall may block it. In Passive FTP, the client initiates both the control and data connections, which satisfies the firewall restriction.\n\nb) FTP Commands\n\nftp remote-server.example.com\nUSER research_user\nPASS ********\nTYPE I\nEPSV\nCWD /data/project\nSTOR dataset.zip\nSIZE dataset.zip\n\nThe client connects, authenticates with username and password, switches to binary mode for the large ZIP file, enters passive mode, navigates to /data/project, uploads dataset.zip, and verifies the remote size. Actual clients may also show 150 and 226 responses internally.\n\nc) Reliability Measures\n\n1. Resume interrupted transfers with REST <byte-offset> where supported. If the connection fails, continue from the last successfully transferred byte instead of restarting the entire file. This saves time and bandwidth for files up to 5 GB.\n\n2. Use transfer verification and retry settings. Compare file size and, where available, a checksum after upload; use a stable EPSV/PASV connection, sensible timeouts, and retries to reduce unnecessary retransmissions. Keep the transfer in binary mode and check disk space first.`;

function scrollToSection(id: string, setActiveSection: (id: string) => void) {
  setActiveSection(id);
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

function StatusPill({ children, tone = "blue" }: { children: React.ReactNode; tone?: "blue" | "mint" | "coral" | "paper" }) {
  return <span className={`status-pill status-${tone}`}>{children}</span>;
}

function RouteMark({ compact = false }: { compact?: boolean }) {
  return <span className={`route-mark ${compact ? "route-mark-compact" : ""}`} aria-hidden="true"><i className="route-chevron route-chevron-one" /><i className="route-chevron route-chevron-two" /><i className="route-node" /></span>;
}

function SectionIntro({ eyebrow, title, body, number }: { eyebrow: string; title: string; body: string; number: string }) {
  return (
    <div className="section-intro">
      <div className="section-number"><span>{number}</span><RouteMark compact /></div>
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h2>{title}</h2>
        <p className="section-body">{body}</p>
      </div>
    </div>
  );
}

export default function Home() {
  const { theme, toggleTheme } = useTheme();
  const [activeSection, setActiveSection] = useState("home");
  const [selectedConstraint, setSelectedConstraint] = useState("firewall");
  const [analyzed, setAnalyzed] = useState(false);
  const [activeMode, setActiveMode] = useState<"passive" | "active">("passive");
  const [stepIndex, setStepIndex] = useState(0);
  const [fileSize, setFileSize] = useState("5 GB");
  const [isRunning, setIsRunning] = useState(false);
  const [generated, setGenerated] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const currentStep = ftpSteps[stepIndex];
  const progress = Math.round((stepIndex / (ftpSteps.length - 1)) * 100);
  const selected = useMemo(() => constraints.find((item) => item.id === selectedConstraint) ?? constraints[0], [selectedConstraint]);
  const SelectedIcon = selected.icon;

  useEffect(() => {
    if (!isRunning) return;
    if (stepIndex >= ftpSteps.length - 1) {
      setIsRunning(false);
      return;
    }
    const timer = window.setTimeout(() => setStepIndex((value) => Math.min(value + 1, ftpSteps.length - 1)), 850);
    return () => window.clearTimeout(timer);
  }, [isRunning, stepIndex]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActiveSection(visible.target.id);
      },
      { rootMargin: "-20% 0px -60% 0px", threshold: [0.08, 0.3, 0.6] },
    );
    sections.forEach(({ id }) => {
      const element = document.getElementById(id);
      if (element) observer.observe(element);
    });
    return () => observer.disconnect();
  }, []);

  const analyze = () => {
    setAnalyzed(true);
    setActiveMode("passive");
    setTimeout(() => scrollToSection("mode", setActiveSection), 80);
  };

  const runSimulator = () => {
    if (stepIndex >= ftpSteps.length - 1) setStepIndex(0);
    setIsRunning(true);
  };

  const resetSimulator = () => {
    setIsRunning(false);
    setStepIndex(0);
  };

  const generateAnswer = () => {
    setGenerated(true);
    setTimeout(() => scrollToSection("answer", setActiveSection), 80);
  };

  const copyAnswer = async () => {
    try {
      await navigator.clipboard.writeText(answerText);
      toast.success("Exam answer copied to clipboard");
    } catch {
      toast.error("Clipboard access is unavailable in this browser");
    }
  };

  return (
    <div className="app-shell">
      <aside className={`chapter-rail ${mobileNavOpen ? "rail-open" : ""}`}>
        <div className="rail-brand">
          <RouteMark /><img src="/manus-storage/ftp-route-logo_75a00d8b.png" alt="Route node logo" className="brand-mark generated-brand-mark" />
          <div>
            <span className="brand-name">route / lab</span>
            <span className="brand-subtitle">CN · 204</span>
          </div>
          <button className="mobile-close" onClick={() => setMobileNavOpen(false)} aria-label="Close navigation"><X size={18} /></button>
        </div>
        <div className="rail-rule" />
        <div className="rail-label">Study path</div>
        <nav className="chapter-nav" aria-label="Study path">
          {sections.map((section) => (
            <button
              key={section.id}
              className={`chapter-link ${activeSection === section.id ? "active" : ""}`}
              onClick={() => {
                scrollToSection(section.id, setActiveSection);
                setMobileNavOpen(false);
              }}
            >
              <span className="chapter-index">{section.number}</span>
              <span>{section.label}</span>
              {activeSection === section.id && <ChevronRight size={14} className="chapter-arrow" />}
            </button>
          ))}
        </nav>
        <div className="rail-bottom">
          <div className="rail-status"><span className="status-dot" /> Educational simulation</div>
          <p>No real FTP connection is being made.</p>
          <button className="theme-toggle" onClick={toggleTheme} aria-label="Toggle light and dark theme">
            {theme === "light" ? <Moon size={15} /> : <Sun size={15} />}
            <span>{theme === "light" ? "Dark canvas" : "Light canvas"}</span>
          </button>
        </div>
      </aside>

      <main className="main-canvas">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setMobileNavOpen(true)} aria-label="Open navigation"><Menu size={20} /></button>
          <div className="breadcrumb"><RouteMark compact /><span>COMPUTER NETWORKS</span><ChevronRight size={13} /><span className="breadcrumb-current">FTP PLANNING</span></div>
          <div className="topbar-tools">
            <span className="build-label">interactive study sheet <span className="build-dot" /></span>
            <button className="icon-button" onClick={toggleTheme} aria-label="Toggle theme">{theme === "light" ? <Moon size={16} /> : <Sun size={16} />}</button>
          </div>
        </header>

        <section id="home" className="hero-section page-section">
          <div className="hero-copy">
            <StatusPill tone="blue"><span className="live-dot" /> Constraint solver · FTP</StatusPill>
            <h1>The firewall<br /><em>decides</em> the mode.</h1>
            <p className="hero-lede">Turn a dense file-transfer prompt into a defensible network design. Follow the evidence, run the protocol, and leave with an answer you can write.</p>
            <div className="hero-actions">
              <button className="primary-button" onClick={() => scrollToSection("problem", setActiveSection)}>Inspect the problem <ArrowRight size={16} /></button>
              <button className="text-button" onClick={generateAnswer}>Jump to exam answer <ArrowDown size={16} /></button>
            </div>
            <div className="hero-meta"><span><span className="meta-label">CASE</span> FTP-05G</span><span><span className="meta-label">MODE</span> guided</span><span><span className="meta-label">MARKS</span> 25</span></div>
          </div>
          <div className="hero-visual" aria-label="Illustration of a client routing through a firewall to a server">
            <img src="/manus-storage/ftp-signal-room-hero_34d7fc65.png" alt="Cobalt network route between a client, firewall and server" />
            <div className="hero-visual-label label-client"><Laptop size={14} /> client</div>
            <div className="hero-visual-label label-firewall"><ShieldAlert size={14} /> firewall</div>
            <div className="hero-visual-label label-server"><Server size={14} /> remote server</div>
            <div className="hero-visual-stamp"><span>OUT</span><strong>→</strong><span>ONLY</span></div>
          </div>
        </section>

        <section id="problem" className="paper-section page-section">
          <SectionIntro number="01" eyebrow="The prompt" title="One transfer. Six constraints." body="The team needs to move a large dataset from a local server to a remote FTP server. Your job is not to recite a command list — it is to make every choice survive the network policy." />
          <div className="problem-layout">
            <div className="scenario-note">
              <div className="note-pin" />
              <p className="note-kicker">Scenario / research team</p>
              <h3>Plan the route before you move the payload.</h3>
              <p>A research team is transferring large datasets between a local server and a remote FTP server. The network has a firewall, and the transfer must be reliable, efficient, and structurally faithful.</p>
              <div className="note-footer"><FileCode2 size={15} /> <span>dataset.zip · up to 5 GB</span></div>
            </div>
            <div className="problem-facts">
              <div className="fact-row"><span className="fact-key">Source</span><span className="fact-value"><HardDrive size={15} /> Local server</span></div>
              <div className="fact-row"><span className="fact-key">Destination</span><span className="fact-value"><Server size={15} /> Remote FTP server</span></div>
              <div className="fact-row"><span className="fact-key">Access</span><span className="fact-value"><LockKeyhole size={15} /> Username + password</span></div>
              <div className="fact-row"><span className="fact-key">Payload</span><span className="fact-value"><FileArchive size={15} /> Binary archive</span></div>
              <div className="problem-callout"><CircleAlert size={16} /><span>The highest-risk constraint is the firewall: incoming connections to the client are not allowed.</span></div>
            </div>
          </div>
        </section>

        <section id="constraints" className="ink-section page-section">
          <div className="ink-grid-texture" />
          <SectionIntro number="02" eyebrow="Constraint analyzer" title="Trace the rule to its consequence." body="Select a constraint to inspect its impact. Then run the complete analysis to reveal the mode that satisfies the whole set." />
          <div className="constraint-layout">
            <div className="constraint-list">
              {constraints.map((item, index) => {
                const Icon = item.icon;
                return (
                  <button key={item.id} className={`constraint-card ${selectedConstraint === item.id ? "selected" : ""}`} onClick={() => setSelectedConstraint(item.id)}>
                    <span className={`constraint-icon tone-${item.tone}`}><Icon size={18} /></span>
                    <span className="constraint-copy"><span className="constraint-number">0{index + 1}</span><strong>{item.label}</strong><small>{item.rule}</small></span>
                    <ChevronRight size={16} className="constraint-chevron" />
                  </button>
                );
              })}
            </div>
            <div className="analysis-panel">
              <div className="analysis-panel-top"><span className="eyebrow">Selected signal</span><span className="analysis-live"><span className="status-dot" /> live reasoning</span></div>
              <div className="analysis-heading"><span className={`constraint-icon tone-${selected.tone}`}><SelectedIcon size={21} /></span><div><h3>{selected.label}</h3><p>{selected.rule}</p></div></div>
              <div className="analysis-track"><div className="track-step"><span className="track-number">01</span><div><strong>Constraint</strong><p>{selected.rule}</p></div></div><ArrowRight size={15} /><div className="track-step"><span className="track-number coral-number">02</span><div><strong>Impact</strong><p>{selected.impact}</p></div></div><ArrowRight size={15} /><div className="track-step"><span className="track-number mint-number">03</span><div><strong>Solution</strong><p>{selected.solution}</p></div></div></div>
              <button className="analysis-button" onClick={analyze}><Sparkles size={16} /> {analyzed ? "Analysis complete" : "Analyze constraints"} <ArrowRight size={15} /></button>
              {analyzed && <div className="analysis-result"><div className="result-check"><CheckCircle2 size={20} /></div><div><span className="eyebrow">Recommended solution</span><h3>PASSIVE FTP</h3><p>Outgoing-only firewall + client-initiated data channel = compatible route.</p></div><span className="result-mark">A</span></div>}
            </div>
          </div>
          <div className="constraint-check-strip"><div className="check-strip-title"><RouteMark compact /><ShieldCheck size={18} /><span>Constraint check</span><span className="check-strip-line" /></div><div className="check-items"><span><Check size={14} /> outgoing only → Passive FTP</span><span><Check size={14} /> username/password → supported</span><span><Check size={14} /> up to 5 GB → binary mode</span><span><Check size={14} /> original path → preserved</span></div></div>
        </section>

        <section id="mode" className="mode-section page-section">
          <SectionIntro number="03" eyebrow="FTP mode" title="Two routes. One survives the firewall." body="The control connection can look identical in both modes. The decision turns on who opens the data connection — and whether that direction is allowed." />
          <div className="mode-tabs" role="tablist" aria-label="FTP mode comparison">
            <button className={activeMode === "passive" ? "mode-tab active" : "mode-tab"} onClick={() => setActiveMode("passive")}><span className="mode-tab-index">01</span>Passive FTP <StatusPill tone="mint">recommended</StatusPill></button>
            <button className={activeMode === "active" ? "mode-tab active" : "mode-tab"} onClick={() => setActiveMode("active")}><span className="mode-tab-index">02</span>Active FTP <StatusPill tone="coral">blocked path</StatusPill></button>
          </div>
          <div className={`mode-diagram ${activeMode === "active" ? "diagram-active" : "diagram-passive"}`}>
            <div className="diagram-header"><div><span className="eyebrow">Connection trace / {activeMode === "passive" ? "client-led" : "server-led"}</span><h3>{activeMode === "passive" ? "The client opens both doors." : "The server knocks from the outside."}</h3></div><div className={`mode-status ${activeMode === "passive" ? "mode-good" : "mode-bad"}`}>{activeMode === "passive" ? <CheckCircle2 size={16} /> : <CircleAlert size={16} />}{activeMode === "passive" ? "Firewall-compatible" : "May be blocked"}</div></div>
            <div className="node-flow">
              <div className="flow-node"><div className="node-icon client-node"><Laptop size={22} /></div><span>Client</span><small>behind firewall</small></div>
              <div className="flow-lines"><div className="flow-line control-line"><span className="flow-line-label">control · TCP 21</span><div className="arrow-track"><span className="moving-dot" /> <ArrowRight size={17} /></div><strong>client → server</strong></div><div className={`flow-line data-line ${activeMode === "active" ? "blocked-line" : ""}`}><span className="flow-line-label">data · negotiated port</span><div className="arrow-track">{activeMode === "passive" ? <><span className="moving-dot" /> <ArrowRight size={17} /></> : <><X size={17} className="blocked-icon" /> <ArrowLeftIcon /></>}</div><strong>{activeMode === "passive" ? "client → server" : "server → client"}</strong></div></div>
              <div className="flow-node"><div className="node-icon server-node"><Server size={22} /></div><span>FTP server</span><small>{activeMode === "passive" ? "opens a port" : "calls back"}</small></div>
              <div className="firewall-gate"><ShieldAlert size={18} /><span>FIREWALL</span><small>OUT ↗ only</small></div>
            </div>
            <div className="diagram-caption"><span className="caption-index"><RouteMark compact />{activeMode === "passive" ? "PASS / 01" : "ACT / 02"}</span><p>{activeMode === "passive" ? "With EPSV or PASV, the server announces a data endpoint and the client makes the outbound connection. No incoming connection to the client is required." : "In Active FTP, the client advertises a port and the server initiates the data channel back to the client. An outgoing-only firewall can reject this callback."}</p></div>
          </div>
          <div className="comparison-table-wrap"><div className="comparison-title"><span className="eyebrow">Decision table</span><span>Read across the constraint, not down the protocol name.</span></div><div className="comparison-table"><div className="comparison-row comparison-head"><span>Feature</span><span>Active FTP</span><span>Passive FTP</span></div><div className="comparison-row"><span>Data connection initiated by</span><span className="bad-cell">Server <X size={14} /></span><span className="good-cell">Client <Check size={14} /></span></div><div className="comparison-row"><span>Requires incoming client connection</span><span className="bad-cell">Yes <X size={14} /></span><span className="good-cell">No <Check size={14} /></span></div><div className="comparison-row"><span>Works with outgoing-only firewall</span><span className="bad-cell">Usually unsuitable <X size={14} /></span><span className="good-cell">Suitable <Check size={14} /></span></div></div></div>
        </section>

        <section id="commands" className="ink-section command-section page-section">
          <div className="ink-grid-texture" />
          <SectionIntro number="04" eyebrow="Command simulator" title="Run the transfer, one command at a time." body="This is a guided simulation, not a live FTP session. Step through the protocol to see when authentication, binary mode, passive negotiation, upload, and verification happen." />
          <div className="simulator-layout">
            <div className="simulator-console">
              <div className="console-top"><div className="console-lights"><span /><span /><span /></div><span className="console-title"><Terminal size={14} /> simulated-session.log</span><StatusPill tone="coral">no live connection</StatusPill></div>
              <div className="console-output" aria-live="polite">
                <div className="console-line dim-line"># Educational Simulation — No real FTP connection is being made.</div>
                {ftpSteps.slice(0, stepIndex + 1).map((step, index) => <div key={step.label} className={`console-block ${index === stepIndex ? "latest-block" : ""}`}><div className="console-command"><span className="prompt">$</span>{step.command}</div><div className="console-response">{step.response}</div></div>)}
                {stepIndex === ftpSteps.length - 1 && <div className="console-line success-line"><CheckCircle2 size={14} /> Transfer verified · 5,368,709,120 bytes</div>}
              </div>
              <div className="console-progress"><div className="progress-copy"><span>sequence progress</span><strong>{progress}%</strong></div><div className="progress-track"><div className="progress-fill" style={{ width: `${progress}%` }} /></div></div>
            </div>
            <div className="simulator-controls">
              <div className="control-card"><div className="control-card-head"><div><span className="eyebrow">Payload size</span><h3>Choose a test file</h3></div><FileArchive size={20} /></div><div className="size-options">{["100 MB", "1 GB", "2 GB", "5 GB"].map((size) => <button key={size} className={fileSize === size ? "size-option active" : "size-option"} onClick={() => setFileSize(size)}>{size}</button>)}</div><p className="control-note"><Zap size={14} /> Binary mode is required for {fileSize} of ZIP data.</p></div>
              <div className="control-card step-card"><div className="control-card-head"><div><span className="eyebrow">Current step / 0{stepIndex + 1}</span><h3>{currentStep.label}</h3></div><span className="step-circle">{stepIndex + 1}</span></div><p>{currentStep.detail}</p><div className="step-command-chip"><Code2 size={14} /><code>{currentStep.command.split("\n")[0]}</code></div><div className="simulator-buttons"><button className="primary-button compact" onClick={runSimulator}>{isRunning ? <><span className="button-spinner" /> Running</> : <><Play size={15} /> {stepIndex === ftpSteps.length - 1 ? "Run again" : "Run sequence"}</>}</button><button className="icon-button inverse" onClick={resetSimulator} aria-label="Reset simulator"><RotateCcw size={16} /></button></div></div>
              <div className="step-nav">{ftpSteps.map((step, index) => <button key={step.label} className={`step-dot ${index <= stepIndex ? "done" : ""} ${index === stepIndex ? "current" : ""}`} onClick={() => { setIsRunning(false); setStepIndex(index); }} aria-label={`Go to ${step.label}`}><span>{index + 1}</span>{index < ftpSteps.length - 1 && <i />}</button>)}</div>
            </div>
          </div>
          <div className="command-notes"><div><span className="note-icon"><Network size={17} /></span><span><strong>EPSV / PASV</strong><small>Actual clients may print passive negotiation plus 150 and 226 responses around the data transfer.</small></span></div><div><span className="note-icon"><Clipboard size={17} /></span><span><strong>SIZE dataset.zip</strong><small>Compare the remote byte count with the local file; use a checksum when the server supports one.</small></span></div></div>
        </section>

        <section id="reliability" className="paper-section page-section">
          <SectionIntro number="05" eyebrow="Reliability + efficiency" title="Protect the time you already spent." body="For a 5 GB transfer, reliability is not a footnote. These two measures reduce the cost of a dropped connection and catch a corrupt or incomplete payload." />
          <div className="reliability-grid"><div className="reliability-card primary-rel"><div className="rel-index">01 / PRIMARY</div><div className="rel-icon"><TimerReset size={24} /></div><h3>Resume interrupted transfers</h3><code>REST &lt;byte-offset&gt;</code><p>If the connection fails, resume from the last successfully transferred position instead of sending the whole file again. This saves time and bandwidth, especially for very large files.</p><div className="rel-footer"><span>less repeat work</span><ArrowRight size={16} /></div></div><div className="reliability-card secondary-rel"><div className="rel-index">02 / PRIMARY</div><div className="rel-icon"><FileCheck2 size={24} /></div><h3>Verify, retry, and monitor</h3><code>SIZE + checksum where supported</code><p>Compare the remote size after upload, use a checksum if available, and pair a stable EPSV/PASV connection with sensible timeout and retry settings.</p><div className="rel-footer"><span>trust the payload</span><ArrowRight size={16} /></div></div></div>
          <div className="efficiency-strip"><Gauge size={18} /><div><strong>Small settings, compounding gains</strong><span>Check disk space first · stay in binary mode · monitor transfer status · retry only what failed.</span></div><StatusPill tone="mint">optimized route</StatusPill></div>
        </section>

        <section id="answer" className="answer-section page-section">
          <div className="answer-top"><SectionIntro number="06" eyebrow="Final answer generator" title="Run the chain. See the marks appear." body="Generate a concise response structured for a 25-mark university exam question. It includes the decision, the sequence, and exactly two reliability measures." /><div className="answer-actions"><button className="primary-button" onClick={generateAnswer}><Sparkles size={16} /> {generated ? "Answer regenerated" : "Generate exam answer"}</button>{generated && <button className="secondary-button" onClick={copyAnswer}><Copy size={15} /> Copy answer</button>}</div></div>
          <div className={`answer-sheet ${generated ? "answer-revealed" : ""}`}>
            <div className="sheet-paper-texture" />
            <div className="sheet-header"><div><span className="eyebrow"><RouteMark compact /> CN / FTP planning</span><h3>Exam-ready response</h3></div><div className="sheet-stamp">{generated ? <><CheckCircle2 size={15} /> 25 / 25 covered</> : <><Clock3 size={15} /> waiting for generator</>}</div></div>
            {generated ? <div className="answer-content"><div className="answer-column"><div className="answer-block"><span className="answer-label">A · FTP mode <b>7 marks</b></span><h4>Passive FTP</h4><p>The client is behind a firewall that allows outgoing connections only. Active FTP may be blocked because the server attempts to establish the data connection back to the client. Passive FTP is appropriate because the client initiates both the control and data connections.</p></div><div className="answer-block"><span className="answer-label">B · Command sequence <b>10 marks</b></span><pre>{`ftp remote-server.example.com\nUSER research_user\nPASS ********\nTYPE I\nEPSV\nCWD /data/project\nSTOR dataset.zip\nSIZE dataset.zip`}</pre><p>These commands connect, authenticate, select binary mode, negotiate passive data transfer, navigate, upload, and verify. A real client may also show 150 and 226 responses.</p></div><div className="answer-block"><span className="answer-label">C · Reliability measures <b>8 marks</b></span><ol><li><strong>Resume:</strong> use REST with the last byte offset after an interruption.</li><li><strong>Verify + retry:</strong> compare size or checksum and configure sensible retries over a stable passive connection.</li></ol></div></div><div className="marks-column"><span className="eyebrow">Coverage map</span><div className="marks-total"><strong>25</strong><span>/ 25 marks<br />mapped</span></div><div className="marks-bar"><span style={{ width: generated ? "100%" : "0%" }} /></div><div className="mark-row"><Check size={14} /> Mode + firewall <b>7</b></div><div className="mark-row"><Check size={14} /> Commands <b>10</b></div><div className="mark-row"><Check size={14} /> Reliability <b>8</b></div><div className="ready-note"><ShieldCheck size={16} /><span><strong>Ready to write</strong>Every constraint has a matching decision.</span></div></div></div> : <div className="answer-empty"><div className="empty-orbit"><FileKey2 size={29} /></div><h3>Your answer sheet is blank — for now.</h3><p>Generate the response to map every choice back to the constraint that caused it.</p><button className="secondary-button" onClick={generateAnswer}>Build the answer <ArrowRight size={15} /></button></div>}
          </div>
          <div className="final-recommendation"><div className="final-mark"><RouteMark compact /></div><div><span className="eyebrow">Final recommended solution</span><p>Use <strong>Passive FTP</strong> with username/password authentication and binary transfer mode. Navigate to <code>/data/project</code>, upload <code>dataset.zip</code>, verify the transfer, and use resume/retry plus transfer verification to improve reliability for large files.</p></div></div>
        </section>

        <footer className="site-footer"><div><img src="/manus-storage/ftp-route-logo_75a00d8b.png" alt="" className="footer-mark" /><span>route / lab · FTP constraint solver</span></div><span>Educational simulation · built for understanding, not live transfer</span></footer>
      </main>
    </div>
  );
}

function ArrowLeftIcon() {
  return <ArrowRight size={17} className="flip-arrow" />;
}
