# Design Directions

## Approach 1 — Signal Room Editorial
**Very Brief Intro:** A calm, high-contrast networking lab interface that treats the solution as a visible chain of evidence: constraints become signals, signals become a decision, and the decision becomes an exam-ready answer. Deep ink surfaces, cobalt accents, and warm paper notes make technical learning feel focused and tactile.

**Probability:** 0.07

## Approach 2 — Packet Garden
**Very Brief Intro:** A light, optimistic study interface inspired by annotated network maps and field guides. Soft mint, paper white, and coral highlights use playful diagrams and generous whitespace to reduce intimidation around protocol mechanics.

**Probability:** 0.03

## Approach 3 — Protocol Console
**Very Brief Intro:** A restrained dark operations console with terminal typography, status lights, and animated connection traces. It emphasizes systems thinking and the feeling of watching a protocol execute in real time.

**Probability:** 0.09

# Chosen Approach — Signal Room Editorial

## Design Movement
Contemporary editorial information design with influences from Swiss grid systems, technical field notes, and observability dashboards. The aesthetic is structured but not sterile: each section should read as a distinct instrument in a learning workflow.

## Core Principles
1. **Make the reasoning visible.** The interface should show the constraint → consequence → decision chain instead of presenting Passive FTP as a memorized answer.
2. **Contrast is instructional.** Deep ink panels hold diagrams and simulated terminal output; warm paper panels hold explanation and exam-ready prose.
3. **Use motion as evidence.** Arrows, progress, and state changes should clarify data flow, never decorate it.
4. **Prefer editorial asymmetry.** Mix a persistent left rail, offset cards, and wide reading bands rather than centering every section in identical boxes.

## Color Philosophy
The signature palette pairs **signal cobalt** with a near-black ink and a sunlit paper tone. Cobalt marks the active decision, trusted links, and progress. Ink creates a quiet technical workspace for command output. Paper keeps explanations approachable and gives the answer generator the feeling of a handout worth revising. A restrained mint is reserved for validated constraints; coral is reserved for blocked paths and firewall warnings.

## Layout Paradigm
A persistent vertical chapter rail anchors the experience while the main canvas scrolls through editorial bands. The hero uses a split composition: a concise problem statement on the left and a live constraint readout on the right. Subsequent sections alternate between full-bleed ink diagrams, asymmetric two-column explanations, and a final answer sheet that intentionally resembles a marked-up exam page.

## Signature Elements
1. **Constraint chips:** Small numbered tokens that visually connect each rule to its impact and resolution.
2. **Connection traces:** Thin cobalt lines with directional markers that animate only when a mode or simulator step is active.
3. **Exam paper footer:** The generated answer closes on a warm paper panel with mark coverage, a 'ready to write' status, and a clipped-corner edge.

## Interaction Philosophy
Every primary action should expose the next layer of reasoning. Clicking Analyze Constraints reveals not only the recommendation but also the failed Active FTP path and the satisfied Passive FTP path. The simulator advances one step at a time so the student can read the command and response before moving on. Toggles and buttons should feel like physical switches: immediate, legible, and reversible.

## Animation
Use quick 160–240ms ease-out transitions for buttons, tabs, and state changes. Connection traces slide from client to server when a step activates; blocked arrows stop with a short opacity drop rather than a dramatic shake. Section entrances may use a 40ms stagger across cards. Never animate large layout shifts. Respect `prefers-reduced-motion` by disabling trace movement and keeping state changes instantaneous.

## Typography System
Use **Space Grotesk** for headlines, labels, and section numerals: its geometric forms feel technical without becoming terminal cosplay. Use **DM Sans** for explanatory body copy and controls for calm readability. Use **IBM Plex Mono** for commands, addresses, status codes, and compact metadata. Headline hierarchy: 12px uppercase kicker with tracking, 48–72px display title, 26–34px section title, 15–17px body copy, and 12–13px mono metadata.

## Brand Essence
A visual tutor for turning FTP constraints into a defensible network design, built for students who need to understand the answer before they write it.

**Personality:** rigorous, calm, encouraging.

## Brand Voice
Headlines should be direct and evidence-led. CTAs should sound like an invitation to inspect the logic, not a generic conversion prompt. Microcopy should explain the consequence of each action.

Example lines:
- “The firewall decides the mode.”
- “Run the chain. See the marks appear.”

## Wordmark & Logo
A compact symbol made from two offset chevrons forming a routed path into a square node. The left chevron represents a constraint, the right chevron represents a decision, and the node represents a verified outcome. The mark should appear without text as a cobalt-on-ink icon and as a small favicon.

## Signature Brand Color
**Signal Cobalt — #2F6BFF.** It is vivid enough to indicate an active network path, but clean enough to sit beside paper and ink without feeling like a neon interface.

## Style Decisions
- Keep the experience light by default with dark ink sections for technical readouts.
- Use paper textures and clipped corners sparingly as editorial cues, not as decoration on every card.
- Reserve coral for firewall blocks and avoid red as a generic error color.
- Keep command output monospaced and functional; do not use terminal styling for the whole app.
